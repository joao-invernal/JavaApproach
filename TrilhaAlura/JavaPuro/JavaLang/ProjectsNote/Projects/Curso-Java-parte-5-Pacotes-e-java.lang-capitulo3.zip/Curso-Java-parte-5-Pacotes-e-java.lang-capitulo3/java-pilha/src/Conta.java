
public class Conta {
	
	void deposita() throws MinhaExcecao {
		
	}

}
