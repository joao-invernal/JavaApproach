
public class MinhaExcecao extends Exception{ 

	public MinhaExcecao(String msg) {
		super(msg);
	}
}
